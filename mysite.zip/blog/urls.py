from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list, name='post_list'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('post/new/', views.post_new, name="post_new"),
    path('post/<int:pk>/edit/', views.post_edit, name='post_edit'),
]

# post_list라는 view가 루트 URL에 할당되었습니다. 이 URL 패턴은 빈 문자열에 매칭이 되고(''), 
# 장고 URL 확인자(resolver)는 전체 URL경로에서 접두어에 포함되는 도메인 이름을 무시하고 받아들입니다.
# 이 패턴은 장고에게 누군가 웹사이트에 'http://127.0.0.1:8000/'주소로 들어왔을 때 views.post_list를 보여주라고 말해줍니다.
# name은 URL에 이름을 붙인 것으로 뷰를 식별한다. 뷰의 이름과 같아도 달라도 된다.